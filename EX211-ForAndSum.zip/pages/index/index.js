// pages/kj/ForAndSum/index.js
var start; //定义起点数、终点数和求和结果三个全局变量
Page({
  startNum: function(e) {
    start = parseInt(e.detail.value); //将input组件value值转换为整数并赋值
  },
  
  calc: function() {
  
    for (var i =1; i <= 5; i++) {
      start =start*0.03+start; //利用for循环求和
    }
    this.setData({
      sum: start //将全局变量sum的值渲染到视图层
    })
  }
})