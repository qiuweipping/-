// pages/kj/RandomSum/index.js
var rand, sum;//定义全局变量
function createRand() {
  rand = []; //初始化数组变量
  for (var i = 0; i < 7; i++) {
    var r = (Math.random() * 30+1).toFixed(0) * 1; //产生100以内的随机数并转换为数值类型
    rand.push(r); //将产生的随机数添加到数组中
  }
};

Page({
  onLoad: function() {
    createRand(); //调用产生随机数函数
    this.setData({
      rand: rand,
    })
  },
  newRand: function() {
    createRand(); //调用产生随机数函数
    this.setData({
      rand: rand,
    })
  }
})